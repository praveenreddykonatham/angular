import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin/admin.component';

const routes: Routes = [
{path: 'login',component:LoginComponent},
{path:'admin',component:AdminComponent},
{path:'',component:LoginComponent},
//path:'' redirect to home
{path:'**',component:LoginComponent}];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
