import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { LoginComponent } from './login/login.component';

import { HttpClientModule } from '../../node_modules/@angular/common/http';
import {ReactiveFormsModule, FormsModule} from '@angular/forms';
import { AdminComponent } from './admin/admin.component'
@NgModule({
  ///all user defined components,directives,pipes
  declarations: [
    AppComponent,
    LoginComponent,
    AdminComponent
  ],
  //all user defined and predefined modules
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
  ],
  //all are user defined services
  providers: [],
  ///kick starting the application[Root component name ]
  bootstrap: [AppComponent]
})
export class AppModule { }
