import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from '../../../node_modules/rxjs';
import { User } from '../model/user.model';
@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) {}

    baseUrl:string='http://localhost:5000/loginpage';
    //get all users 
    
    getUser(){
      return this.http.get<User[]>(this.baseUrl);
    }

    
    login(email:string,password:string,role:string): Observable<any>{
     // console.log("service");
      return this.http.get<User>(this.baseUrl+'/logindetails?email='+email+'&password='+password+'&role='+role);
      // http://localhost:5000/loginpage/customerlogin?email=viswa@capgemini.com&password=viswa@123&role=customer
    }

   
    
}
