import { Component } from '@angular/core';

/*[app-root]->matches attribute
./app-root->matches the class
app-root->matches the element*/
@Component({
  //html page is called
  selector: 'app-root',
 templateUrl: './app.component.html',
/* template:`<h1>welcome to My App..!</h1>
 <hr/>
 <h2>this is root component</h2>`,*/
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Online Cap Store';
  
  todaysDate=new Date();
  
}
