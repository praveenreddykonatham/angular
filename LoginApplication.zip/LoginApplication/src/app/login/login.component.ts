import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '../../../node_modules/@angular/forms';
import { Router } from '../../../node_modules/@angular/router';
import { UserService } from '../services/user.service';
import { first } from 'rxjs/operators';
import { User } from '../model/user.model';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  //instance variables-by default public in typescript
  loginForm: FormGroup;
  submitted: boolean = false;
  invalidLogin: boolean = false;
  usermod: User[];

  constructor(private formBuilder: FormBuilder, private router: Router, private userService: UserService) { }
  onSubmit() {
    this.submitted = true;
    console.log(this.submitted);
    //if validation is failed it should return to validate to again
    if (this.loginForm.invalid) {
      return;
    }
    let username = this.loginForm.controls.email.value;
    let password = this.loginForm.controls.password.value;
    console.log(username);
    let role = this.loginForm.controls.role.value;
 

    console.log(username + " " + password + " "+role);

    this.userService.login(username,password,role)
    .pipe(first())
    .subscribe(
        data => {
                  if(role=="customer")
                    {
                      this.router.navigate(["/customer-page"]);
                    }

                   else if(role=="merchant")
                      { 
                           this.router.navigate(["/merchant-page"]);
                      }
                    else if (role=="admin") 
                        {
                            if(username == "admin@gmail.com" && password == "123456789")
                                {
                                     this.router.navigate(['/admin-page']);
                                }
                               else
                                  this.invalidLogin=true;
                         }
                    else
                      {
                          this.invalidLogin=true;
                      }
                 }
                );
  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required],
      role: ['', Validators.required]
      
    });

  }
}



