import { Component } from '@angular/core';
import { SignUpService } from '../services/signup.service';
import { FormBuilder, FormGroup, Validators } from '../../node_modules/@angular/forms';
import { Router } from '../../node_modules/@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'sign-up-app';
  addForm: FormGroup;
  submitted: boolean = false;

  constructor(private formBuilder: FormBuilder, private router: Router,private signupService:SignUpService) { }
    
}
