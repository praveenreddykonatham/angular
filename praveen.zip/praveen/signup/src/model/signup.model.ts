export class SignUP{
    cname:string;
    email:string;
    password:string;
    customer:string;
}