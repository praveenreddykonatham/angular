package com.cg.onlinecapstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.onlinecapstore.model.Merchant;
@Repository
public interface MerchantDao extends JpaRepository<Merchant, String>{
	@Query("select merchant from Merchant merchant where merchant.email=:email")
	 public Merchant findByEmail(@Param("email") String email);

	 @Query("select merchant from Merchant merchant where merchant.email=:email")
	 public Merchant getEmail(@Param("email") String email);
	 
	 @Query("select merchant from Merchant merchant where merchant.email=:email and merchant.password=:password")
	 public Merchant getLoginDetails(@Param("email") String email,@Param("password") String password);
}
