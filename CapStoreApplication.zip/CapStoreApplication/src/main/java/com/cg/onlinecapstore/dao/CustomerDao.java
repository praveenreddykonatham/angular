package com.cg.onlinecapstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.onlinecapstore.model.Customer;
@Repository
public interface CustomerDao extends JpaRepository<Customer, String>{
	@Query("select customer from Customer customer where customer.email=:email")
	 public Customer findByEmail(@Param("email") String email);

	 @Query("select customer from Customer customer where customer.email=:email")
	 public Customer getEmail(@Param("email") String email);
	 
	 @Query("select customer from Customer customer where customer.email=:email and customer.password=:password")
	 public Customer getLoginDetails(@Param("email") String email,@Param("password") String password);
}
