package com.cg.onlinecapstore.execption;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class MyExceptionMapper {
	@ExceptionHandler(value=ApplicationException.class)
	@ResponseBody
	protected ResponseEntity<String> handleError(ApplicationException ex){
		String message=ex.getMessage();
		System.out.println("Caught exception "+message);

		return new ResponseEntity<String>(message,HttpStatus.BAD_REQUEST);
	}

}
