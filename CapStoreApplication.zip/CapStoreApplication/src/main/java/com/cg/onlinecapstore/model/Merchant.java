package com.cg.onlinecapstore.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="merchant")

public class Merchant implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int Mid;
	@Column(name="MNAME")
	private String Mname;
	@Column(name="EMAIL")
	private String email;
	@Column(name="PASSWORD")
	private String password;
	@Column(name="CATEGORY")
	private String catogory;
	@Column(name="PRODUCTNAME")
	private String productName;
	@Column(name="CREATED_DATE")
	private Date date;
	
	//@OneToMany(targetEntity=Product.class)
	//private List product;

	public int getMid() {
		return Mid;
	}

	public void setMid(int mid) {
		Mid = mid;
	}

	public String getMname() {
		return Mname;
	}

	public void setMname(String mname) {
		Mname = mname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCatogory() {
		return catogory;
	}

	public void setCatogory(String catogory) {
		this.catogory = catogory;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	
	public Merchant() {
	// TODO Auto-generated constructor stub
	}

	public Merchant(int mid, String mname, String email, String password, String catogory, String productName,
			Date date)
	{
		super();
		Mid = mid;
		Mname = mname;
		this.email = email;
		this.password = password;
		this.catogory = catogory;
		this.productName = productName;
		this.date = date;
		
	}

	@Override
	public String toString() {
		return "Merchant [Mid=" + Mid + ", Mname=" + Mname + ", email=" + email + ", password=" + password
				+ ", catogory=" + catogory + ", productName=" + productName + ", date=" + date + "]";
	}
	
	
}
