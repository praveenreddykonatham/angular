package com.cg.onlinecapstore.service;

import org.springframework.stereotype.Service;

import com.cg.onlinecapstore.model.Customer;
import com.cg.onlinecapstore.model.Merchant;

@Service
public interface CustomerLoginService {
	
	 public Customer findByEmail(String email);

	 public Customer getEmail(String email);
	 public Customer getLoginDetails(String email,String password);

	 public Merchant findEmail(String email);

	 public Merchant getByEmail(String email);
	 public Merchant getMerchantLoginDetails(String email,String password);
}
