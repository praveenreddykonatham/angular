package com.cg.onlinecapstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.onlinecapstore.dao.CustomerDao;
import com.cg.onlinecapstore.dao.MerchantDao;
import com.cg.onlinecapstore.execption.ApplicationException;
import com.cg.onlinecapstore.model.Customer;
import com.cg.onlinecapstore.model.Merchant;

@Service
public class CustomerLoginServiceImpl implements CustomerLoginService{
	@Autowired
	private CustomerDao user;
	@Autowired
	private MerchantDao merchant;

	 @Transactional
	@Override
	public Customer findByEmail(String email) {
		
		Customer cus= user.findByEmail(email);
		 return cus;
	}
	 @Transactional
	@Override
	public Customer getEmail(String email) {
		
		Customer cus=user.getEmail(email);
	
		 return cus;
	}
	@Override
	@Transactional
	public Customer getLoginDetails(String email, String password) {
		boolean status = false;
		System.out.println(email + " " +password);
		List<Customer> mer2 =user.findAll();
		for(Customer m : mer2)
		{
			if(m.getEmail().equals(email) && m.getPassword().equals(password))
			{
				System.out.println(m);
				status =true;
				return m;
			}
		}
		
		if(status!=true) {
			 throw new ApplicationException("Account not Exists in Record");
		 }
		
		return null;
	}
	
	@Override
	 @Transactional
	public Merchant findEmail(String email) {
		
		Merchant mer=merchant.findByEmail(email);
				return mer;
	}
	
	@Override
	 @Transactional
	public Merchant getByEmail(String email) {
		
		Merchant mer=merchant.getEmail(email);
			return mer;
	}
		
	@Override
	@Transactional
	public Merchant getMerchantLoginDetails(String email, String password) {
			boolean status = false;
		System.out.println(email + " " +password);
		List<Merchant> mer =merchant.findAll();
		for(Merchant m : mer)
		{
			if(m.getEmail().equals(email) && m.getPassword().equals(password))
			{
			//	System.out.println(m);
				status =true;
				return m;
			}
		}
		
		if(status!=true) {
			 throw new ApplicationException("Account not Exists in Record");
		 }
		
		return null;
		}
}
