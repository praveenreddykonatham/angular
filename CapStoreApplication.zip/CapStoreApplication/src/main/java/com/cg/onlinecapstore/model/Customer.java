package com.cg.onlinecapstore.model;
	import java.io.Serializable;
	import java.util.Date;
	import javax.persistence.*;

	@Entity
	@Table(name="customer")
	
	public class Customer implements Serializable{
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private int cid;
		
		@Column(name="CNAME")
		private String cname;
		
		@Column(name="CMOBILENUMBER")
		
		private String mobileNumber;
		
		@Column(name="CEMAIL")
		
		private String email;
		
		@Column(name="PASSWORD")
		
		private String password;
		
		@Column(name="CREATED_DATE")
		
		private Date date;
		
		@Column(name="LOGINTIME")
		
		private Date loginTime;
		
		@Column(name="LOGOUTTIME")
		
		private Date logoutTime;
		
		@Column(name="REFERENCENUMBER")
		
		private int refNumber;

		public int getCid() {
			return cid;
		}

		public void setCid(int cid) {
			this.cid = cid;
		}

		public String getCname() {
			return cname;
		}

		public void setCname(String cname) {
			this.cname = cname;
		}

		public String getMobileNumber() {
			return mobileNumber;
		}

		public void setMobileNumber(String mobileNumber) {
			this.mobileNumber = mobileNumber;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getPassword() {
			return password;
		}

		public void setPasswod(String password) {
			this.password = password;
		}

		public Date getDate() {
			return date;
		}

		public void setDate(Date date) {
			this.date = date;
		}

		public Date getLoginTime() {
			return loginTime;
		}

		public void setLoginTime(Date loginTime) {
			this.loginTime = loginTime;
		}

		public Date getLogoutTime() {
			return logoutTime;
		}

		public void setLogoutTime(Date logoutTime) {
			this.logoutTime = logoutTime;
		}

		public int getRefNumber() {
			return refNumber;
		}

		public void setRefNumber(int refNumber) {
			this.refNumber = refNumber;
		}
	public Customer() {
		// TODO Auto-generated constructor stub
	}
		public Customer(int cid, String cname, String mobileNumber, String email, String password, Date date, Date loginTime,
				Date logoutTime, int refNumber) {
			super();
			this.cid = cid;
			this.cname = cname;
			this.mobileNumber = mobileNumber;
			this.email = email;
			this.password = password;
			this.date = date;
			this.loginTime = loginTime;
			this.logoutTime = logoutTime;
			this.refNumber = refNumber;
		}

		@Override
		public String toString() {
			return "Customer [cid=" + cid + ", cname=" + cname + ", mobileNumber=" + mobileNumber + ", email=" + email
					+ ", password=" + password + ", date=" + date + ", loginTime=" + loginTime + ", logoutTime=" + logoutTime
					+ ", refNumber=" + refNumber + "]";
		}
		 
	}


